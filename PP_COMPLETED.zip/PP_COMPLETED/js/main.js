$(document).ready(function() {

     // Hide Header on on scroll down
    var didScroll;
    var lastScrollTop = 0;
    var delta = 5;
    var navbarHeight = $('header').outerHeight();

    $(window).scroll(function(event){
        didScroll = true;
    });

    setInterval(function() {
        if (didScroll) {
            hasScrolled();
            didScroll = false;
        }
    }, 150);

    function hasScrolled() {
        var st = $(this).scrollTop();
        
        // Make sure they scroll more than delta
        if(Math.abs(lastScrollTop - st) <= delta)
            return;
        
        // If they scrolled down and are past the navbar, add class .nav-up.
        // This is necessary so you never see what is "behind" the navbar.
        if (st > lastScrollTop && st > navbarHeight){
            // Scroll Down
            $('header').removeClass('nav-down').addClass('nav-up');
        
        } else {
            // Scroll Up
            if(st + $(window).height() < $(document).height()) {
                $('header').removeClass('nav-up').addClass('nav-down');
            }
        }
        
        lastScrollTop = st;

        if(st >= $('.hero_cont').outerHeight()) {
            $("a[href='#top']").removeClass('hidden');
        }

        if(st < $('.hero_cont').outerHeight()) {
            $("a[href='#top']").addClass('hidden');
        }

    }


      // ============== //
     $("a[href='#top']").click(function() {
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

     // For Smooth Scrolling from clicking links for the navbar

     $("a[href='#cont_sec']").click(function(){
        $("html, body").animate({ 
            scrollTop: $("#cont_sec").offset().top }, "slow");
     });

     $("a[href='#abt_sec']").click(function(){
        $("html, body").animate({ 
            scrollTop: $("#abt_sec").offset().top }, "slow");
     });

     $("a[href='#proj_sec']").click(function(){
        $("html, body").animate({ 
            scrollTop: $("#proj_sec").offset().top }, "slow");
     });


      $(function(){
      $(".anim_type").typed({
        strings: ["Learn | Eat | Sleep | Repeat", "Designer | Learner | Developer", "Crazy | Creative | Geek "],
        typeSpeed: 0,
        loop: true
      });

  });

});
